$(document).ready(function(){
    $(".currencies-list li").first().addClass("active");
    $(".currencies-panels div").first().addClass("active");
});
